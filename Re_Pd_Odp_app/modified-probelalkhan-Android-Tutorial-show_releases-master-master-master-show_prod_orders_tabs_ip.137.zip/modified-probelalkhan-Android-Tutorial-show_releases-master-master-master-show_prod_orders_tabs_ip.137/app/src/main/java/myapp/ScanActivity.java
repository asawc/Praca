//package com.example.codescannerjava;
package myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
//import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.budiyev.android.codescanner.*;
import com.google.zxing.Result;

import net.simplifiedcoding.simplifiedcoding.R;
import net.simplifiedcoding.simplifiedcoding.RequestHandler;
import net.simplifiedcoding.simplifiedcoding.SharedPrefManager;
import myapp.api.URLs;
import myapp.model.Product;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class ScanActivity extends AppCompatActivity {
    private CodeScanner mCodeScanner;
    private Button buttonCheck, buttonLogout2;
    //final String[] productsymbol_array = new String[1];
    public String symbol; // = productsymbol_array[0];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        CodeScannerView scannerView = findViewById(R.id.scanner_view);
        buttonCheck = (Button) findViewById(R.id.buttonCheck);
        buttonLogout2 = (Button) findViewById(R.id.buttonLogout2);
        mCodeScanner = new CodeScanner(this, scannerView);

        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast toast = Toast.makeText(ScanActivity.this, result.getText(), Toast.LENGTH_SHORT); //.show();
                        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 330);
                        toast.show();
                        symbol = result.getText();
                    }
                });
            }
        });

        mCodeScanner.startPreview();

        scannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCodeScanner.startPreview();
            }
        });

        findViewById(R.id.buttonCheck).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //finish();
                //ScanActivity.getInstance(getApplicationContext()).logout();
                employeeLogin();
                productLogin();
            }

        });

        findViewById(R.id.buttonLogout2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                SharedPrefManager.getInstance(getApplicationContext()).logout();
            }
        });
    }


    // public void checkItemInWarehouse() {
    //Intent intent = new Intent(this, ProductInfoActivity.class);
    // startActivity(intent);
    private void productLogin() {


        class ProductLogin extends AsyncTask<Void, Void, String> {

            ProgressBar progressBar;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //progressBar = (ProgressBar) findViewById(R.id.progressBar);
                //progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //progressBar.setVisibility(View.GONE);


                try {
                    //converting response to json object
                    JSONObject obj = new JSONObject(s);

                    //if no error in response
                    if (!obj.getBoolean("error")) {
                        Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                        //getting the product from the response
                        JSONObject productJson = obj.getJSONObject("object");

                        //creating a product object
                        Product product = new Product(
                                productJson.getInt("id"),
                                productJson.getInt("quantity"),
                                productJson.getString("productname"),
                                productJson.getString("productsymbol")
                        );

                        //storing the product in shared preferences
                        SharedPrefManager.getInstance(getApplicationContext()).productLogin(product);

                        //starting the profile activity
                        finish();
                        startActivity(new Intent(getApplicationContext(), ProductInfoActivity.class));
                    } else {
                        Toast.makeText(getApplicationContext(), "Product does not exist in warehouse database", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                //creating request handler object
                RequestHandler requestHandler = new RequestHandler();

                //creating request parameters
                HashMap<String, String> params = new HashMap<>();
                params.put("productsymbol", symbol);
                //params.put("password", password);

                //returing the response
                return requestHandler.sendPostRequest(URLs.URL_CHECK_PRODUCT, params);
            }
        }

        ProductLogin ul = new ProductLogin();
        ul.execute();
    }

    private void employeeLogin() {


        class EmployeeLogin extends AsyncTask<Void, Void, String> {

            ProgressBar progressBar;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                //progressBar = (ProgressBar) findViewById(R.id.progressBar);
                //progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //progressBar.setVisibility(View.GONE);


                try {
                    //converting response to json object
                    JSONObject obj = new JSONObject(s);

                    //if no error in response
                    if (!obj.getBoolean("error")) {
                        Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                        //getting the product from the response
                        JSONObject employeeJson = obj.getJSONObject("employee");

                        //creating a product object
                        Employee employee = new Employee(
                                employeeJson.getInt("id"),
                                employeeJson.getString("surname"),
                                employeeJson.getString("name"),
                                employeeJson.getString("symbol")
                        );

                        //storing the employee in shared preferences
                        SharedPrefManager.getInstance(getApplicationContext()).employeeLogin(employee);

                        //starting the profile activity
                        finish();
                        startActivity(new Intent(getApplicationContext(), EmployeeInfoActivity.class));
                    } else {
                        Toast.makeText(getApplicationContext(), "Employee does not exist in the database", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                //creating request handler object
                RequestHandler requestHandler = new RequestHandler();

                //creating request parameters
                HashMap<String, String> params = new HashMap<>();
                params.put("symbol", symbol);
                //params.put("password", password);

                //returing the response
                return requestHandler.sendPostRequest(URLs.URL_CHECK_EMPLOYEE, params);
            }
        }

        EmployeeLogin ul = new EmployeeLogin();
        ul.execute();
    }
}