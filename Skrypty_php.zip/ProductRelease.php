<?php

class ProductRelease {
		
	private $product;
	private $status;
	private $quantity;
	
	public function __construct($product, $status, $quantity) {
		$this->product = $product;
		$this->status = $status;
		$this->quantity = $quantity;
	}
	
	public function toAssocArray() {
		$array = array();
		$array['product'] = $this->product;
		$array['status'] = $this->status;
		$array['quantity'] = $this->quantity;
		return $array;
	}
}

?>